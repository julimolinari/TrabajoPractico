<?php

namespace App\Controllers;
use App\Models\TrabajadoresEnPedido;
use App\Models\DetallePedido;
use Clases\Token;

class TrabajadoresEnPedidoController{
    public function add($request, $response, $args) {
        $headerValueString = $request->getHeaderLine('token');
        $decodedToken = Token::decode($headerValueString);        
        $result="Pedido asignado correctamente";
        $idDetalle = $args['id'];
        try{
            
            $params = (array)$request->getParsedBody(); 
            $detalle = DetallePedido::find($idDetalle);
            if($detalle != null){
                
                $detalle->tiempo = $params['tiempo'];
                $detalle->estado = "en preparacion";
                
                switch($decodedToken->tipo)
                {
                    case "bartender":                        
                        $sectores = array("tragos");
                    break;
                    case "cervecero":
                        $sectores = array("cervezas");
                    break;
                    case "cocinero":
                        $sectores = array("cocina", "candy bar");                        
                    break;
                    default:
                        $sectores = array("");
                }
               
                if(in_array($detalle->sector, $sectores)) 
                {
                    
                    $detalle->save();                    
                                     
                }else{
                    $result = array("respuesta" => "El pedido no pertenece a tu sector.");
                    $response = $response->withStatus(401);
                }
            }else{
                $result = array("respuesta" => "El pedido indicado no existe."); 
                $response = $response->withStatus(404);
            }
        }catch(\Throwable $sh)
        {
            $result = array("respuesta" =>"Error: Datos inválidos. No se pudo asignar el pedido.");
            $response = $response->withStatus(400);
        }

        $response->getBody()->write(json_encode($result));
        return $response;
    }
}