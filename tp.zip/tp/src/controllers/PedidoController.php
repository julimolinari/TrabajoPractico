<?php

namespace App\Controllers;
use App\Models\Pedido;
use App\Models\DetallePedido;
use App\Models\Mesa;
use Clases\Token;
use Clases\Utils;

class PedidoController{
    public function add($request, $response, $args) {
        $headerValueString = $request->getHeaderLine('token');
        $decodedToken = Token::decode($headerValueString);
        if($decodedToken->tipo == "mozo")
        {
            try{
                $pedido = new Pedido;
                $params = (array)$request->getParsedBody(); 
                $pedido->codigo_pedido = Utils::generateRandomString();
                while(Pedido::find($pedido->codigo_pedido) != null) //Prevent repeated keys
                {
                    $pedido->codigo_pedido = Utils::generateRandomString();
                }
                $pedido->estado = "en preparacion";
                $pedido->importe = $params['importe'];
                echo($pedido);
                //Checkear que la mesa exista
                $mesa = Mesa::find($params['codigo_mesa']);
                
                if($mesa != null)
                {
                    $pedido->codigo_mesa = $params['codigo_mesa'];
                    $mesa->estado = "esperando pedido";   

                    //Crear detalle del pedido con todos sus productos                    
                    if(array_key_exists("bebida", $params) && $params['bebida'] != "")
                    {
                        $detalle_pedido = new DetallePedido;
                        $detalle_pedido->codigo_pedido = $pedido->codigo_pedido;
                        $detalle_pedido->producto = $params["bebida"];
                        $detalle_pedido->sector = "tragos";
                        $detalle_pedido->tiempo = 0; //Se lo definirá quien lo prepare
                        $detalle_pedido->estado = "en espera";
                        
                        $detalle_pedido->save();
                    }
                    
                    if(array_key_exists("cerveza", $params) && $params['cerveza'] != "")
                    {
                        $detalle_pedido = new DetallePedido;
                        $detalle_pedido->codigo_pedido = $pedido->codigo_pedido;
                        $detalle_pedido->producto = $params["cerveza"];
                        $detalle_pedido->sector = "cervezas";
                        $detalle_pedido->tiempo = 0; //Se lo definirá quien lo prepare
                        $detalle_pedido->estado = "en espera";
                        
                        $detalle_pedido->save();
                    }
                    
                    if(array_key_exists("comida", $params) && $params['comida'] != "")
                    {
                        $detalle_pedido = new DetallePedido;
                        $detalle_pedido->codigo_pedido = $pedido->codigo_pedido;
                        $detalle_pedido->producto = $params["comida"];
                        $detalle_pedido->sector = "cocina";
                        $detalle_pedido->tiempo = 0; //Se lo definirá quien lo prepare
                        $detalle_pedido->estado = "en espera";
                        
                        $detalle_pedido->save();
                    }
                    
                    if(array_key_exists("postre", $params) && $params['postre'] != "")
                    {
                        $detalle_pedido = new DetallePedido;
                        $detalle_pedido->codigo_pedido = $pedido->codigo_pedido;
                        $detalle_pedido->producto = $params["postre"];
                        $detalle_pedido->sector = "candy bar";
                        $detalle_pedido->tiempo = 0; //Se lo definirá quien lo prepare
                        $detalle_pedido->estado = "en espera";
                        
                        $detalle_pedido->save();
                    }
                    $mesa->save();
                    $pedido->save();  
                    $result = array("pedido" => $pedido->codigo_pedido);                  
                }else{
                    $result = array("respuesta" => "La mesa indicada no existe.");
                    $response = $response->withStatus(400);
                }
            }catch(\Throwable $sh)
            {
                $result = array("respuesta" => "No se pudo crear el pedido.");
                echo($sh);
                $response = $response->withStatus(400);
            }
        }else{
            $result = array("respuesta" => "Solo permitido para mozos.");
            $response = $response->withStatus(401);
        }
        $response->getBody()->write(json_encode($result));
        return $response;
    }

    public function servirPedido($request, $response, $args) {
        $headerValueString = $request->getHeaderLine('token');
        $decodedToken = Token::decode($headerValueString);
        if($decodedToken->tipo == "mozo")
        {
            $pedido = Pedido::find($args['id']);
            if($pedido != null)
            {
                $detalle = DetallePedido::where("estado", "!=", "listo para servir")
                                        ->where("codigo_pedido", $pedido->codigo_pedido)->first();
               
                if($detalle == null)
                {
                    $pedido->estado = "servido";
                    $mesa = Mesa::find($pedido->codigo_mesa);
                    $mesa->estado = "con clientes comiendo";
                    $pedido->save();
                    $mesa->save();
                    echo( "La cuenta es: $");
                    echo($pedido->importe);
                    $result = array("respuesta" => "Pedido servido");
                }else{
                    $result = array("respuesta" => "El pedido no está listo para servir.");
                    $response = $response->withStatus(400);
                }
            }else{
                $result = array("respuesta" => "El pedido indicado no existe.");
                $response = $response->withStatus(404);
            }
        }else{
            $result = array("respuesta" => "Solo permitido para mozos.");
            $response = $response->withStatus(401);
        }

        $response->getBody()->write(json_encode($result));
        return $response;
    }

    public function delete($request, $response, $args) {
        $headerValueString = $request->getHeaderLine('token');
        $decodedToken = Token::decode($headerValueString);
        if($decodedToken->tipo == "socio" || $decodedToken->tipo == "mozo")
        {
            $codigo_pedido = $args['id'];
            $pedido = Pedido::find($codigo_pedido);
            
            if($pedido != null)
            {            
                DetallePedido::where("codigo_pedido", $pedido->codigo_pedido)->delete();
                $pedido->delete();
                $result = array("respuesta" =>"Pedido cancelado exitosamente.");
            }else{
                $result = array("respuesta" =>"Error: Pedido no encontrado.");
                $response = $response->withStatus(400);
            }
        }else{
            $result = array("respuesta" => "Solo permitido para mozos y socios.");
            $response = $response->withStatus(401);
        }
        $response->getBody()->write(json_encode($result));
        return $response;
    }
}