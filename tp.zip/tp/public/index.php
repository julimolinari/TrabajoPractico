<?php

use App\Controllers\DetallePedidoController;
use App\Controllers\EncuestaController;
use App\Controllers\MesaController;
use App\Controllers\TrabajadorController;
use App\Controllers\PedidoController;
use App\Controllers\TrabajadoresEnPedidoController;
use Psr\Http\Message\ResponseInterface as Response;
use Psr\Http\Message\ServerRequestInterface as Request;
use Slim\Factory\AppFactory;
use Slim\Routing\RouteCollectorProxy;
use Slim\Middleware\RoutingMiddleware;
use App\Middlewares\AuthMiddleware;
use App\Middlewares\JsonMiddleware;
use Config\Database;

require __DIR__ . '/../vendor/autoload.php';

$app = AppFactory::create();
$app->setBasePath('/SLIM/tp/public'); 
$app->addRoutingMiddleware();
$app->addBodyParsingMiddleware();

$conn =new Database;

$app->group('/empleados',function (RouteCollectorProxy $group) {
    $group->post('[/]', TrabajadorController::class.":add");
    $group->post('/login[/]', TrabajadorController::class.":login");    
    $group->get('[/]', TrabajadorController::class.":getAll")->add(new AuthMiddleware);
})->add(new JsonMiddleware);

$app->group('/mesas',function (RouteCollectorProxy $group) {
    $group->post('[/]', MesaController::class.":add");
    $group->put('/{id}[/]', MesaController::class.":updateEstado")->add(new AuthMiddleware);
    $group->get('[/]', MesaController::class.":getAll");
})->add(new JsonMiddleware);

$app->group('/pedidos',function (RouteCollectorProxy $group) {
    $group->post('[/]', PedidoController::class.":add")->add(new AuthMiddleware);
    $group->get('[/]', DetallePedidoController::class.":getAll")->add(new AuthMiddleware);
    $group->post('/tomar/{id}[/]', TrabajadoresEnPedidoController::class.":add")->add(new AuthMiddleware);
    $group->put('/listo/{id}[/]', DetallePedidoController::class.":updateEstado")->add(new AuthMiddleware);
    $group->post('/servir/{id}[/]', PedidoController::class.":servirPedido")->add(new AuthMiddleware);
    $group->delete('/{id}[/]', PedidoController::class.":delete")->add(new AuthMiddleware);
})->add(new JsonMiddleware);

$errorMiddleware = $app->addErrorMiddleware(true, true, true);
$app->run();
